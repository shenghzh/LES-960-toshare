gen_xdmf.f90 generates a XDMF file for visualizing a time series 3D fields in a uniform Caresian grid. Instructions on its usage can be found in the first lines of the .f90 file.
