the DNS code writes all the output files to this folder by default
