.. _api-label:

cuDecomp API 
============

The following sections describe the types and functions available in the cuDecomp library for C/C++ and Fortran programs.

.. toctree::

 api/c_api
 api/f_api

