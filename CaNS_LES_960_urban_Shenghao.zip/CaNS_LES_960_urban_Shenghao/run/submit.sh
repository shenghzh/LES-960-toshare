#!/bin/bash

#SBATCH --mail-type=ALL
#SBATCH --mail-user=shenghzh@gmail.com
#SBATCH --job-name="cube array"  # 
#SBATCH --ntasks-per-node 32   #
#SBATCH --time=08:00:00 # 
#SBATCH --partition=compute # 
#SBATCH -N 2                             # Number of Nodes (48 x n = total CPUs)
#SBATCH --mem-per-cpu=4G   # 

## SBATCH --exclusive    #


# ----- Set the number of processors ----- #
n_procs=64

# ----- Load all the modules ----- # 
module load 2022r2 intel/oneapi-all
module use /beegfs/apps/unsupported/lmod/linux-rhel8-x86_64/Core
module load libfabric

# --- RUN CASE
mpirun -np $n_procs ./cans > out.log

